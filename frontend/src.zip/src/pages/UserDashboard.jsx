import React, { useCallback, useEffect, useMemo, useState } from "react";
import { useOutletContext, Link, useNavigate } from "react-router-dom";
import toast from "react-hot-toast";
import { RotateCcw, CalendarDays, AlertTriangle, ShoppingBag, Grid3X3 } from "lucide-react";

import ProductGrid from "../features/products/ProductGrid";
import RecipeList from "../features/recipes/RecipeList";
import { useCart } from "../context/CartContext";
import { useAuth } from "../context/AuthContext";
import { UI_LABELS } from "../ui/labels";
import {
  getHourInTimeZone,
  getStoredTimeZone,
  LOCATION_EVENT,
} from "../utils/locationTime";

const DASHBOARD_CATEGORIES = [
  "All",
  "Vegetables",
  "Fruits",
  "Grains",
  "Dairy",
  "Spices",
];

export default function UserDashboard() {
  const { activeCategory, searchTerm = "" } = useOutletContext();
  const { user } = useAuth();
  const navigate = useNavigate();
  const [timeZone, setTimeZone] = useState(() => getStoredTimeZone());
  const [dashboardCategory, setDashboardCategory] = useState("All");

  const {
    items: cartItems,
    updateItem,
  } = useCart();

  const safeCartItems = useMemo(
    () => (Array.isArray(cartItems) ? cartItems : []),
    [cartItems]
  );

  const withCartGuard = useCallback(
    (fn) => {
      if (safeCartItems.length === 0) {
        toast("Your cart is empty — add a few items first.");
        return;
      }
      fn();
    },
    [safeCartItems.length]
  );

  const handleReorder = useCallback(() => {
    withCartGuard(() => {
      let touched = 0;
      for (const item of safeCartItems) {
        const id = item?.variantId;
        const qty = Number(item?.quantity ?? 0);
        if (!id || !Number.isFinite(qty)) continue;
        updateItem(id, Math.max(1, qty + 1));
        touched += 1;
      }
      if (touched > 0) toast.success(`Reordered ${touched} item${touched === 1 ? "" : "s"}`);
    });
  }, [safeCartItems, updateItem, withCartGuard]);

  const handleAddStock = useCallback(() => {
    withCartGuard(() => {
      let touched = 0;
      for (const item of safeCartItems) {
        const id = item?.variantId;
        const qty = Number(item?.quantity ?? 0);
        if (!id || !Number.isFinite(qty)) continue;
        const next = Math.max(2, qty);
        if (next !== qty) {
          updateItem(id, next);
          touched += 1;
        }
      }
      toast.success(touched > 0 ? `Stocked up ${touched} item${touched === 1 ? "" : "s"}` : "Already stocked up");
    });
  }, [safeCartItems, updateItem, withCartGuard]);

  const handleRestockNow = useCallback(() => {
    withCartGuard(() => {
      let touched = 0;
      for (const item of safeCartItems) {
        const id = item?.variantId;
        const qty = Number(item?.quantity ?? 0);
        if (!id || !Number.isFinite(qty)) continue;
        if (qty <= 1) {
          updateItem(id, 2);
          touched += 1;
        }
      }
      toast.success(touched > 0 ? `Restocked ${touched} item${touched === 1 ? "" : "s"}` : "Nothing to restock");
    });
  }, [safeCartItems, updateItem, withCartGuard]);

  useEffect(() => {
    const handler = () => setTimeZone(getStoredTimeZone());
    window.addEventListener(LOCATION_EVENT, handler);
    return () => window.removeEventListener(LOCATION_EVENT, handler);
  }, []);

  const getGreeting = () => {
    const hour = getHourInTimeZone(timeZone);
    if (hour >= 5 && hour < 12) return "Good Morning";
    if (hour >= 12 && hour < 17) return "Good Afternoon";
    if (hour >= 17 && hour < 22) return "Good Evening";
    return "Hello";
  };

  const getMealTime = () => {
    const hour = getHourInTimeZone(timeZone);
    if (hour >= 5 && hour < 11) return "breakfast";
    if (hour >= 11 && hour < 15) return "lunch";
    if (hour >= 15 && hour < 18) return "snacks";
    return "dinner";
  };

  const getSubtitle = () => {
    const mealTime = getMealTime();
    if (!user) return "Welcome! Discover our fresh collection.";

    if (mealTime === "breakfast") {
      return "Time for breakfast? Here's what's running low!";
    }
    if (mealTime === "lunch") {
      return "Lunch time! Here's what you'll need.";
    }
    if (mealTime === "dinner") {
      return "Dinner plans? Check what's running low.";
    }
    return "Snack time! Here's what's running low.";
  };

  return (
    <div className="space-y-12 dashboard-page">
      <div className="flex flex-col gap-8 lg:flex-row lg:gap-6">
        {/* ================= LEFT + CENTER ================= */}
        <div className="flex-1 space-y-8">
          {/* Immersive Hero Section */}
          <div className="dashboard-hero">
            <h1 className="text-2xl md:text-3xl font-bold">
              {getGreeting()}{user ? `, ${user.username}` : ""} 👋
            </h1>
            <p className="mt-2 text-base md:text-lg max-w-lg">
              Fresh groceries delivered to your doorstep in minutes.
            </p>
            <div className="mt-6 flex flex-wrap items-center gap-3">
              <button
                type="button"
                onClick={() => navigate("/groceries/products")}
                className="hero-btn-primary"
              >
                <ShoppingBag size={18} />
                Start shopping
              </button>
              <button
                type="button"
                onClick={() => navigate("/groceries/categories")}
                className="hero-btn-secondary"
              >
                <Grid3X3 size={18} />
                Browse categories
              </button>
            </div>
          </div>

          {/* Quick Action Cards - horizontal row matching target UI */}
          <div className="grid grid-cols-1 gap-4 md:grid-cols-3">
            {/* BUY AGAIN */}
            <div className="dashboard-action-card p-5">
              <div className="flex items-center gap-3 mb-3">
                <div className="grid h-10 w-10 place-items-center rounded-xl bg-slate-100/80 text-slate-600">
                  <RotateCcw size={20} />
                </div>
                <div>
                  <p className="text-sm font-bold text-slate-900 uppercase tracking-wide">
                    {UI_LABELS.actions.buyAgain.title}
                  </p>
                  <p className="text-xs text-slate-500">
                    {UI_LABELS.actions.buyAgain.description}
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={handleReorder}
                aria-label={UI_LABELS.actions.buyAgain.cta}
                className="w-full rounded-full bg-emerald-600 py-2.5 text-sm font-bold text-white shadow-sm transition hover:bg-emerald-700 focus:outline-none focus-visible:ring-2 focus-visible:ring-emerald-400/40 active:scale-[0.99]"
              >
                {UI_LABELS.actions.buyAgain.cta}
              </button>
            </div>

            {/* MONTHLY STOCK */}
            <div className="dashboard-action-card p-5">
              <div className="flex items-center gap-3 mb-3">
                <div className="grid h-10 w-10 place-items-center rounded-xl bg-emerald-100/80 text-emerald-600">
                  <CalendarDays size={20} />
                </div>
                <div>
                  <p className="text-sm font-bold text-slate-900 uppercase tracking-wide">
                    {UI_LABELS.actions.monthlyStock.title}
                  </p>
                  <p className="text-xs text-slate-500">
                    {UI_LABELS.actions.monthlyStock.description}
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={handleAddStock}
                aria-label={UI_LABELS.actions.monthlyStock.cta}
                className="w-full rounded-full bg-emerald-600 py-2.5 text-sm font-bold text-white shadow-sm transition hover:bg-emerald-700 focus:outline-none focus-visible:ring-2 focus-visible:ring-emerald-400/40 active:scale-[0.99]"
              >
                {UI_LABELS.actions.monthlyStock.cta}
              </button>
            </div>

            {/* RUNNING LOW */}
            <div className="dashboard-action-card p-5">
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center gap-3">
                  <div className="grid h-10 w-10 place-items-center rounded-xl bg-amber-100/80 text-amber-600">
                    <AlertTriangle size={20} />
                  </div>
                  <div>
                    <p className="text-sm font-bold text-slate-900 uppercase tracking-wide">
                      {UI_LABELS.actions.runningLow.title}
                    </p>
                    <p className="text-xs text-slate-500">
                      {UI_LABELS.actions.runningLow.description}
                    </p>
                  </div>
                </div>
                <Link
                  to="/groceries/products"
                  className="text-sm font-semibold text-emerald-600 hover:text-emerald-700 whitespace-nowrap"
                >
                  View all →
                </Link>
              </div>
              <button
                type="button"
                onClick={handleRestockNow}
                aria-label={UI_LABELS.actions.runningLow.cta}
                className="w-full rounded-full bg-emerald-600 py-2.5 text-sm font-bold text-white shadow-sm transition hover:bg-emerald-700 focus:outline-none focus-visible:ring-2 focus-visible:ring-emerald-400/40 active:scale-[0.99]"
              >
                {UI_LABELS.actions.runningLow.cta}
              </button>
            </div>
          </div>
        </div>

        {/* ================= RIGHT (Recipes) ================= */}
        <aside className="w-full lg:w-[360px] xl:w-[420px]">
          <RecipeList searchTerm={searchTerm} />
        </aside>
      </div>

      {/* Products Section: "Start here" */}
      <div>
        <div className="mb-6 flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
          <div className="min-w-0">
            <div className="flex items-center justify-between gap-3 sm:justify-start">
              <h2 className="text-xl font-bold text-gray-900">
                Start here
              </h2>

              <Link
                to="/groceries/products"
                className="shrink-0 text-sm font-semibold text-emerald-600 hover:text-emerald-700 sm:hidden"
              >
                See all →
              </Link>
            </div>

            <p className="mt-0.5 text-sm text-slate-500">
              Handpicked just for you
            </p>
          </div>

          <div className="flex items-center gap-3">
            <div className="flex items-center gap-2 overflow-x-auto pb-2 sm:pb-0 scrollbar-hide">
              {DASHBOARD_CATEGORIES.map((cat) => {
                const isActive = dashboardCategory === cat;
                return (
                  <button
                    key={cat}
                    type="button"
                    aria-pressed={isActive}
                    onClick={() => setDashboardCategory(cat)}
                    className={
                      "dashboard-pill whitespace-nowrap px-4 py-1.5 text-sm font-semibold rounded-full transition-all " +
                      (isActive
                        ? "bg-emerald-600 text-white shadow-md"
                        : "bg-white/60 backdrop-blur-sm text-slate-600 border border-white/40 hover:bg-white/80 hover:text-slate-800")
                    }
                  >
                    {cat}
                  </button>
                );
              })}
            </div>

            <Link
              to="/groceries/products"
              className="hidden sm:flex items-center gap-1 shrink-0 whitespace-nowrap text-sm font-semibold text-emerald-600 hover:text-emerald-700"
            >
              See all →
            </Link>
          </div>
        </div>

        <ProductGrid
          category={activeCategory}
          searchTerm={searchTerm}
          filterCategory={activeCategory ? "" : dashboardCategory}
        />
      </div>

      {/* Products Section: "Popular near you" */}
      <div>
        <div className="mb-6 flex items-center justify-between">
          <div>
            <h2 className="text-xl font-bold text-gray-900">Popular near you</h2>
            <p className="mt-0.5 text-sm text-slate-500">Trending items in your area</p>
          </div>
          <Link
            to="/groceries/products"
            className="flex items-center gap-1 text-sm font-semibold text-emerald-600 hover:text-emerald-700"
          >
            See all →
          </Link>
        </div>

        <ProductGrid
          category=""
          searchTerm=""
          filterCategory=""
          limit={4}
        />
      </div>

    </div>
  );
}
