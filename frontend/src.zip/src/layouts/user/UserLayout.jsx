import React, { useCallback, useMemo, useState } from "react";
import { NavLink, Outlet, useLocation, useNavigate } from "react-router-dom";
import { Home, Users, Search, ShoppingBag } from "lucide-react";
import HeaderBar from "./HeaderBar";
import SceneryBackground from "../../components/SceneryBackground";
import { UI_LABELS } from "../../ui/labels";

function DockItem({ to, label, icon: Icon, onClick, isButton = false }) {
  const base =
    "flex flex-col items-center justify-center gap-1 rounded-2xl px-4 py-2 transition-all duration-200 focus:outline-none focus-visible:ring-2 focus-visible:ring-emerald-400/40";

  const inner = (isActive) => (
    <div
      className={
        base +
        " " +
        (isActive
          ? "text-emerald-700"
          : "text-slate-600 hover:text-emerald-700")
      }
    >
      <div
        className={
          "grid h-10 w-10 place-items-center rounded-2xl ring-1 transition-all " +
          (isActive
            ? "bg-white/40 ring-white/40 shadow-[0_10px_25px_rgba(16,185,129,0.18)]"
            : "bg-white/20 ring-white/25 hover:bg-white/30")
        }
      >
        <Icon size={20} />
      </div>
      <span className="hidden sm:block text-[11px] font-semibold tracking-tight">
        {label}
      </span>
    </div>
  );

  if (isButton) {
    return (
      <button type="button" onClick={onClick} className="contents" aria-label={label}>
        {inner(false)}
      </button>
    );
  }

  return (
    <NavLink
      to={to}
      aria-label={label}
      className={({ isActive }) => "contents"}
    >
      {({ isActive }) => inner(isActive)}
    </NavLink>
  );
}

export default function MainLayout() {
  const navigate = useNavigate();
  const location = useLocation();

  const [activeCategory, setActiveCategory] = useState(null);
  const [searchTerm, setSearchTerm] = useState("");

  const focusSearch = useCallback(() => {
    const el = document.getElementById("global-search");
    if (el && typeof el.focus === "function") el.focus();
  }, []);

  const handleSearchDockClick = useCallback(() => {
    if (location.pathname !== "/groceries") {
      navigate("/groceries");
      requestAnimationFrame(() => focusSearch());
    } else {
      focusSearch();
    }
  }, [focusSearch, location.pathname, navigate]);

  const dockItems = useMemo(
    () => [
      { key: "home", label: UI_LABELS.dock.home, to: "/groceries", icon: Home },
      { key: "groups", label: UI_LABELS.dock.groups, to: "/groceries/categories", icon: Users },
      {
        key: "search",
        label: UI_LABELS.dock.search,
        icon: Search,
        onClick: handleSearchDockClick,
        isButton: true,
      },
      { key: "cart", label: UI_LABELS.dock.cart, to: "/groceries/cart", icon: ShoppingBag },
    ],
    [handleSearchDockClick]
  );

  return (
    <div className="min-h-screen flex flex-col">
      {/* SVG Atmospheric Scenery Background */}
      <SceneryBackground />

      <HeaderBar
        searchTerm={searchTerm}
        onSearchTermChange={setSearchTerm}
      />

      <main className="relative z-10 flex-1 p-6 sm:p-8 pb-[calc(10rem+env(safe-area-inset-bottom))] sm:pb-[calc(11rem+env(safe-area-inset-bottom))] bg-transparent">
        <div className="max-w-[1600px] mx-auto w-full">
          <Outlet
            context={{
              activeCategory,
              setActiveCategory,
              searchTerm,
              setSearchTerm,
            }}
          />
        </div>
      </main>

      {/* Floating Dock */}
      <nav
        aria-label="Primary"
        className="fixed bottom-8 left-1/2 z-[60] -translate-x-1/2 lg:hidden"
      >
        <div
          className="
            w-[min(92vw,520px)]
            sm:w-[min(86vw,520px)]
            md:w-[min(60vw,520px)]
            mx-auto
            rounded-full
            border border-white/40
            bg-white/30
            backdrop-blur-xl
            shadow-[0_22px_60px_rgba(0,0,0,0.12)]
          "
        >
          <div className="flex items-center justify-between px-3 py-2">
            {dockItems.map((item) => (
              <DockItem
                key={item.key}
                to={item.to}
                label={item.label}
                icon={item.icon}
                onClick={item.onClick}
                isButton={item.isButton}
              />
            ))}
          </div>
        </div>
      </nav>
    </div>
  );
}